package com.qingping.adblock

import android.content.Context

/** 轻量设置：两个功能开关、“暂停拦截”的应用名单、服务是否连接过。 */
object Prefs {
    private const val FILE = "qingping_prefs"
    private const val K_SKIP = "skip_splash"
    private const val K_REDIRECT = "block_redirect"
    private const val K_EXCLUDED = "excluded_pkgs"
    private const val K_EVER = "ever_connected"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun skipSplash(c: Context) = sp(c).getBoolean(K_SKIP, true)
    fun setSkipSplash(c: Context, on: Boolean) = sp(c).edit().putBoolean(K_SKIP, on).apply()

    fun blockRedirect(c: Context) = sp(c).getBoolean(K_REDIRECT, true)
    fun setBlockRedirect(c: Context, on: Boolean) =
        sp(c).edit().putBoolean(K_REDIRECT, on).apply()

    fun anyEnabled(c: Context) = skipSplash(c) || blockRedirect(c)

    /** 服务至少连接成功过一次。没连接过就掉线提醒，会在你从没开启过的时候打扰你。 */
    fun everConnected(c: Context) = sp(c).getBoolean(K_EVER, false)
    fun markConnected(c: Context) = sp(c).edit().putBoolean(K_EVER, true).apply()

    fun excluded(c: Context): Set<String> = sp(c).getStringSet(K_EXCLUDED, null) ?: emptySet()

    fun setExcluded(c: Context, pkg: String, on: Boolean) {
        val copy = HashSet(excluded(c)) // getStringSet 返回的集合不能直接修改
        if (on) copy.add(pkg) else copy.remove(pkg)
        sp(c).edit().putStringSet(K_EXCLUDED, copy).apply()
    }
}
