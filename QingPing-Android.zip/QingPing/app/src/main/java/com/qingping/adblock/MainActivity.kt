package com.qingping.adblock

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private companion object {
        const val RANGE_TODAY = 0
        const val RANGE_WEEK = 1
        const val RANGE_ALL = 2
    }

    private lateinit var tvStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var btnEnable: TextView
    private lateinit var tvRangeLabel: TextView
    private lateinit var tvHeroCount: TextView
    private lateinit var tvBreakdown: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var list: LinearLayout
    private var range = RANGE_TODAY

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvHint = findViewById(R.id.tvHint)
        btnEnable = findViewById(R.id.btnEnable)
        tvRangeLabel = findViewById(R.id.tvRangeLabel)
        tvHeroCount = findViewById(R.id.tvHeroCount)
        tvBreakdown = findViewById(R.id.tvBreakdown)
        tvEmpty = findViewById(R.id.tvEmpty)
        list = findViewById(R.id.list)

        btnEnable.setOnClickListener { onEnableClick() }
        findViewById<View>(R.id.btnKeepAlive).setOnClickListener { showKeepAlive() }

        findViewById<MaterialSwitch>(R.id.swSkip).apply {
            isChecked = Prefs.skipSplash(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSkipSplash(this@MainActivity, on) }
        }
        findViewById<MaterialSwitch>(R.id.swRedirect).apply {
            isChecked = Prefs.blockRedirect(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setBlockRedirect(this@MainActivity, on) }
        }

        findViewById<MaterialButtonToggleGroup>(R.id.toggleRange).apply {
            check(R.id.btnToday)
            addOnButtonCheckedListener { _, id, checked ->
                if (checked) {
                    range = when (id) {
                        R.id.btnToday -> RANGE_TODAY
                        R.id.btnWeek -> RANGE_WEEK
                        else -> RANGE_ALL
                    }
                    loadStats()
                }
            }
        }

        StatsStore.prune(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        Guard.ensureAlive(this, notify = false) // 被强行停止后，打开一次清屏就能自愈（需 ADB 授权）
        refreshStatus()
        loadStats()
        window.decorView.postDelayed({ if (!isDestroyed) refreshStatus() }, 1000)
    }

    // ------------------------------------------------------------------ 状态

    private fun refreshStatus() {
        val running = AdSkipService.instance != null
        val enabled = Guard.isEnabledInSettings(this)

        val (text, color) = when {
            running -> "● 无障碍服务运行中" to R.color.status_on
            enabled -> "● 已开启，正在等待系统连接服务" to R.color.status_wait
            else -> "● 无障碍服务未开启，目前不会拦截任何广告" to R.color.status_off
        }
        tvStatus.text = text
        tvStatus.setTextColor(getColor(color))
        btnEnable.text = if (running) "管理服务" else "开启服务"

        tvHint.text = buildString {
            if (Build.VERSION.SDK_INT >= 33 && !running) {
                append("Android 13 及以上侧载安装的应用，开关可能是灰色的：先在应用详情页右上角菜单里选“允许受限制的设置”，再回来开启。\n")
            }
            append(
                if (Guard.canWriteSecureSettings(this@MainActivity)) {
                    "已授予自愈权限：服务被系统关闭后，清屏会自己重新开启。想暂停清屏，请关掉上面的两个开关。"
                } else {
                    "想让服务被关闭后自动恢复？在“保活设置”里查看 ADB 授权方法。"
                }
            )
        }
    }

    private fun onEnableClick() {
        val already = AdSkipService.instance != null || Guard.isEnabledInSettings(this)
        if (!already && Guard.tryEnableSelf(this)) {
            Toast.makeText(this, "已自动开启无障碍服务", Toast.LENGTH_SHORT).show()
            window.decorView.postDelayed({ if (!isDestroyed) refreshStatus() }, 1000)
        } else {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    // ------------------------------------------------------------------ 统计

    private fun rangeLabel() = when (range) {
        RANGE_TODAY -> "今日已清除"
        RANGE_WEEK -> "近 7 天已清除"
        else -> "累计已清除"
    }

    private fun loadStats() {
        val since = when (range) {
            RANGE_TODAY -> StatsStore.startOfToday()
            RANGE_WEEK -> System.currentTimeMillis() - 7L * 24 * 3600 * 1000
            else -> 0L
        }
        StatsStore.loadStats(this, since) { render(it) }
    }

    private fun render(stats: List<AppStat>) {
        if (isDestroyed) return
        val splash = stats.sumOf { it.splash }
        val redirect = stats.sumOf { it.redirect }
        tvRangeLabel.text = rangeLabel()
        tvHeroCount.text = (splash + redirect).toString()
        tvBreakdown.text = "开屏跳过 $splash 次，跳转返回 $redirect 次"

        list.removeAllViews()
        tvEmpty.visibility = if (stats.isEmpty()) View.VISIBLE else View.GONE

        val paused = Prefs.excluded(this)
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        for (st in stats) {
            val row = layoutInflater.inflate(R.layout.item_app, list, false)
            val (label, icon) = labelAndIcon(st.pkg)
            row.findViewById<TextView>(R.id.tvName).text =
                if (st.pkg in paused) "$label（已暂停）" else label
            row.findViewById<TextView>(R.id.tvDetail).text =
                "开屏跳过 ${st.splash}，跳转返回 ${st.redirect}，最近 ${fmt.format(Date(st.lastTs))}"
            row.findViewById<TextView>(R.id.tvCount).text = st.total.toString()
            row.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(icon)
            row.setOnClickListener { showDetail(st.pkg, label) }
            list.addView(row)
        }
    }

    private fun labelAndIcon(pkg: String): Pair<String, Drawable?> = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString() to packageManager.getApplicationIcon(ai)
    } catch (e: Exception) {
        pkg to null // 应用已卸载，显示包名
    }

    private fun showDetail(pkg: String, label: String) {
        StatsStore.loadRecent(this, pkg, 25) { rows ->
            if (isDestroyed) return@loadRecent
            val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault())
            val msg = if (rows.isEmpty()) {
                "还没有记录"
            } else {
                rows.joinToString("\n") {
                    val kind = if (it.type == StatsStore.TYPE_SPLASH) "跳过" else "返回"
                    "${fmt.format(Date(it.ts))}  $kind  ${it.detail}"
                }
            }
            val paused = pkg in Prefs.excluded(this)
            AlertDialog.Builder(this)
                .setTitle(label)
                .setMessage(msg)
                .setPositiveButton("关闭", null)
                .setNeutralButton(if (paused) "恢复对此应用的拦截" else "暂停对此应用的拦截") { _, _ ->
                    Prefs.setExcluded(this, pkg, !paused)
                    loadStats()
                }
                .show()
        }
    }

    // ------------------------------------------------------------------ 保活

    private fun showKeepAlive() {
        val items = arrayOf(
            "忽略电池优化",
            "自启动与后台运行管理（各厂商页面）",
            "应用详情页（含“允许受限制的设置”）",
            "ADB 自愈授权命令",
            "防止被一键清理的做法"
        )
        AlertDialog.Builder(this)
            .setTitle("保活设置")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> Guard.openBatterySettings(this)
                    1 -> Guard.openAutoStart(this)
                    2 -> Guard.openAppDetails(this)
                    3 -> showAdbCommand()
                    else -> showCleanTips()
                }
            }
            .show()
    }

    private fun showAdbCommand() {
        val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this)
            .setTitle("授权自愈（可选）")
            .setMessage(
                "手机开启 USB 调试并连接电脑，执行一次：\n\n$cmd\n\n" +
                    "授权后，开机或被系统关闭无障碍时，清屏会自动重新开启，也不用再手动去系统设置里勾选。" +
                    "想暂停清屏，请关闭应用内的两个开关，而不是系统里的无障碍开关。"
            )
            .setPositiveButton("复制命令") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("adb", cmd))
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun showCleanTips() {
        AlertDialog.Builder(this)
            .setTitle("防止被一键清理")
            .setMessage(
                "在最近任务里长按（或下拉）清屏的卡片，选“锁定”。\n\n" +
                    "把清屏加进系统后台管理或一键清理的白名单。\n\n" +
                    "不要在应用详情页点“强行停止”：系统会直接把无障碍服务从已开启列表里移除，应用自己拦不住。\n\n" +
                    "如果已经被强行停止：重新打开一次清屏。授予过 ADB 自愈权限的话，它会自己把服务开回来。"
            )
            .setPositiveButton("知道了", null)
            .show()
    }
}
