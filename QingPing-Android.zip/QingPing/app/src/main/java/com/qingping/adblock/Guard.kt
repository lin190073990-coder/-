package com.qingping.adblock

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast

/** “别让服务掉线”相关的一切：状态检查、自愈、提醒，以及跳转到各种系统设置页。 */
object Guard {
    private const val CHANNEL = "qingping_guard"
    private const val NOTI_ID = 1001

    fun component(ctx: Context) = ComponentName(ctx, AdSkipService::class.java)

    /** 系统设置里是否勾选了本服务。勾选不等于进程在运行，运行状态看 AdSkipService.instance。 */
    fun isEnabledInSettings(ctx: Context): Boolean {
        val raw = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = component(ctx)
        return raw.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    fun canWriteSecureSettings(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /** 需要先用 adb 授予 WRITE_SECURE_SETTINGS。成功后，系统会自动重新绑定无障碍服务。 */
    fun tryEnableSelf(ctx: Context): Boolean {
        if (!canWriteSecureSettings(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            val me = component(ctx)
            val list = (Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .split(':')
                .filter { it.isNotBlank() }
                .toMutableList()
            if (list.none { ComponentName.unflattenFromString(it) == me }) {
                list.add(me.flattenToString())
            }
            Settings.Secure.putString(
                cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":")
            )
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * 开机、覆盖安装、打开应用时调用：该开着却没开着，先自愈；自愈不了，并且服务以前连接过，就发通知。
     * notify=false 用于在应用界面里调用（用户已经在看状态了，不用再弹通知）。
     */
    fun ensureAlive(ctx: Context, notify: Boolean) {
        if (!Prefs.anyEnabled(ctx) || isEnabledInSettings(ctx)) return
        if (tryEnableSelf(ctx)) return
        if (notify && Prefs.everConnected(ctx)) notifyDisabled(ctx)
    }

    private fun notifyDisabled(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (!nm.areNotificationsEnabled()) return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "清屏状态提醒", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            ctx,
            0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("清屏已停止工作")
            .setContentText("无障碍服务被系统关闭了，点这里重新开启")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTI_ID, n)
    }

    fun clearNotification(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTI_ID)
    }

    // ------------------------------------------------------------------ 跳转到系统设置页

    fun openBatterySettings(a: Activity) {
        val pm = a.getSystemService(PowerManager::class.java)
        if (pm != null && pm.isIgnoringBatteryOptimizations(a.packageName)) {
            Toast.makeText(a, "已经在电池优化白名单里了", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            a.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:${a.packageName}"))
            )
        } catch (e: Exception) {
            try {
                a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                openAppDetails(a)
            }
        }
    }

    // 各厂商“自启动管理”页面的组件名，来自社区整理，随系统版本变化，只能尽力而为
    private val AUTOSTART_PAGES = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.hihonor.systemmanager" to "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity",
        "com.meizu.safe" to "com.meizu.safe.permission.SmartBGActivity",
        "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
    )

    /** 依次尝试各厂商的自启动页面，都打不开就退回应用详情页。 */
    fun openAutoStart(a: Activity) {
        for ((pkg, cls) in AUTOSTART_PAGES) {
            try {
                a.startActivity(Intent().setComponent(ComponentName(pkg, cls)))
                return
            } catch (e: Exception) {
                // 这家的页面不存在，试下一家
            }
        }
        Toast.makeText(a, "没找到厂商的自启动页面，请在应用详情里手动设置", Toast.LENGTH_LONG).show()
        openAppDetails(a)
    }

    fun openAppDetails(a: Activity) {
        a.startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:${a.packageName}")
            )
        )
    }
}
