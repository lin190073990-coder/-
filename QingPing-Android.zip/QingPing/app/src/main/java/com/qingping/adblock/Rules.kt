package com.qingping.adblock

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 所有“识别规则”集中在这里。广告 SDK 改版、遇到新的广告样式时，只需要改这个文件。
 * 类名和控件 ID 会随 SDK 版本变化，下面的列表是常见写法，不保证覆盖所有版本。
 */
object Rules {

    // ---------- 开屏“跳过”按钮 ----------

    // 去掉空白、分隔符、括号、箭头之后再匹配，所以 “跳过 | 3s”“3S 跳过”“Skip Ads” 都能命中
    private val SEPARATORS = Regex("[\\s|丨·:：\\-—>＞»›()（）\\[\\]【】<《》]")

    private val SKIP_TEXT = Regex(
        "^(?:" +
            "(?:\\d{1,2}[s秒]?)?(?:点击|點擊)?(?:跳过|跳過|skip)(?:广告|廣告|ads?)?(?:\\d{1,2}[s秒]?)?" +
            "|关闭广告|關閉廣告" +
            ")$"
    )

    private val ID_AD_TOKENS =
        setOf("splash", "ad", "ads", "ksad", "tt", "gdt", "bd", "adv", "advert", "launch")
    private val ID_EXACT =
        setOf("tv_skip", "btn_skip", "skip_btn", "skip_view", "iv_skip", "ll_skip")

    private fun norm(s: CharSequence?): String =
        s?.toString()?.lowercase()?.replace(SEPARATORS, "") ?: ""

    /** 命中返回命中原因（会写进记录，方便排查），没命中返回 null。 */
    fun matchSkip(n: AccessibilityNodeInfo, maxDim: Int): String? {
        // 太大的容器不可能是“跳过”按钮，直接排除，避免点到整屏
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty || r.height() > maxDim * 0.2 || r.width() > maxDim * 0.5) return null

        val t = norm(n.text)
        if (t.isNotEmpty() && t.length <= 14 && SKIP_TEXT.matches(t)) return "text=" + n.text
        val d = norm(n.contentDescription)
        if (d.isNotEmpty() && d.length <= 14 && SKIP_TEXT.matches(d)) {
            return "desc=" + n.contentDescription
        }

        val id = n.viewIdResourceName ?: return null
        val tail = id.substringAfterLast('/').lowercase()
        if (tail in ID_EXACT) return "id=$tail"
        val tokens = tail.split('_', '-')
        if ("skip" in tokens && tokens.any { it in ID_AD_TOKENS }) return "id=$tail"
        return null
    }

    // ---------- 广告落地页（应用内） ----------

    private val LANDING_EXACT = setOf(
        "com.qq.e.ads.ADActivity",
        "com.qq.e.ads.PortraitADActivity",
        "com.qq.e.ads.LandscapeADActivity",
        "com.baidu.mobads.sdk.api.AppActivity",
        "com.baidu.mobads.AppActivity"
    )
    private val LANDING_PARTS = listOf(
        "TTLandingPageActivity",
        "TTPlayableLandingPageActivity",
        "TTVideoLandingPageActivity",
        "AdLandingPageActivity",
        "AdWebViewActivity"
    )

    fun isAdLanding(cls: String?): Boolean =
        cls != null && (cls in LANDING_EXACT || LANDING_PARTS.any { cls.contains(it) })

    // ---------- 广告常把你带去的“系统级”目的地（浏览器、应用商店） ----------
    // 普通第三方应用（淘宝、京东、拼多多……）不用列，服务里会按“用户安装的应用”判断。

    val JUMP_TARGETS = setOf(
        // 浏览器
        "com.android.chrome", "com.android.browser", "com.UCMobile", "com.tencent.mtt",
        "com.huawei.browser", "com.heytap.browser", "com.vivo.browser", "com.miui.browser",
        "com.mi.globalbrowser", "com.baidu.searchbox", "com.quark.browser",
        "com.sec.android.app.sbrowser",
        // 应用商店
        "com.android.vending", "com.huawei.appmarket", "com.xiaomi.market",
        "com.heytap.market", "com.oppo.market", "com.bbk.appstore", "com.hihonor.appmarket",
        "com.tencent.android.qqdownloader", "com.sec.android.app.samsungapps"
    )

    // ---------- 需要完全忽略的系统界面（权限弹窗、输入法、安装器等） ----------

    private val IGNORED = setOf("android", "com.android.settings", "com.google.android.setupwizard")
    private val NOISE_PARTS = listOf(
        "systemui", "permissioncontroller", "packageinstaller", "securitycenter", "safecenter",
        "lbe.security", "systemmanager", "securitypermission", "permissionmanager",
        "iqoo.secure", "setupwizard", "inputmethod"
    )

    fun isNoise(pkg: String): Boolean = pkg in IGNORED || NOISE_PARTS.any { pkg.contains(it) }
}
