package com.qingping.adblock

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager

/**
 * 清屏核心，做两件事：
 *  1) 应用切入前台后的 SPLASH_WATCH_MS 内，轮询控件树，找到“跳过”并点击；
 *  2) 从桌面启动应用后的 REDIRECT_WINDOW_MS 内，如果被广告带去了别的应用或广告落地页，自动“返回”。
 *
 * 全部在主线程执行；所有入口都包了 try/catch——无障碍服务一旦崩溃，系统会把它标记为“已崩溃”并停用。
 */
class AdSkipService : AccessibilityService() {

    companion object {
        private const val TAG = "Qingping"
        private const val DEBUG = true

        private const val SPLASH_WATCH_MS = 7_000L       // 切入应用后，多久内找“跳过”
        private const val REDIRECT_WINDOW_MS = 6_000L    // 从桌面启动应用后，多久内的跳转算广告跳转
        private const val REDIRECT_COOLDOWN_MS = 1_200L  // 两次“返回”的最小间隔，防止连按把应用退出
        private const val POLL_MS = 250L
        private const val MIN_SCAN_GAP_MS = 120L
        private const val SKIP_COOLDOWN_MS = 1_500L
        private const val ENV_REFRESH_MS = 5 * 60_000L
        private const val MAX_NODES = 600
        private const val MAX_DEPTH = 40
        private const val MAX_BACK_RETRY = 2

        /** 界面用它判断服务是否真的在运行（和“系统设置里已勾选”是两回事）。 */
        @Volatile
        var instance: AdSkipService? = null
    }

    private class Session(val pkg: String, val start: Long, val fromLauncher: Boolean) {
        var skipBlockedUntil = 0L
    }

    private class Hit(val node: AccessibilityNodeInfo, val why: String)

    private val main = Handler(Looper.getMainLooper())
    private var session: Session? = null
    private var currentPkg: String? = null
    private var currentClass: String? = null
    private var lastLauncherAt = 0L
    private var lastRedirectAt = 0L
    private var lastScanAt = 0L
    private var envAt = 0L
    private var homes: Set<String> = emptySet()
    private var imes: Set<String> = emptySet()
    private val userAppCache = HashMap<String, Boolean>()

    // ------------------------------------------------------------------ 生命周期

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Prefs.markConnected(this)
        refreshEnv()
        Guard.clearNotification(this)
        Log.i(TAG, "service connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------------ 事件入口

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        try {
            if (!Prefs.anyEnabled(this)) return
            val pkg = event.packageName?.toString() ?: return
            when (event.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ->
                    onWindowChanged(pkg, event.className?.toString())
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> onContentChanged(pkg)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "event failed", e)
        }
    }

    private fun onContentChanged(pkg: String) {
        val s = session ?: return
        if (pkg == s.pkg) scanForSkip(s, throttle = true)
    }

    private fun onWindowChanged(pkg: String, cls: String?) {
        val now = SystemClock.elapsedRealtime()
        if (now - envAt > ENV_REFRESH_MS) refreshEnv()

        // 桌面（包括放在桌面里的“最近任务”）
        if (pkg in homes) {
            lastLauncherAt = now
            currentPkg = pkg
            currentClass = cls
            return
        }
        // 自己、输入法、系统弹窗：完全忽略
        if (pkg == packageName || pkg in imes || Rules.isNoise(pkg)) return

        val prev = currentPkg
        currentPkg = pkg
        currentClass = cls
        if (DEBUG) Log.d(TAG, "window $pkg / $cls")
        val s = session

        // 情况 A：还在同一个应用里。可能是广告落地页（如 GDT 的 ADActivity）。
        if (s != null && s.pkg == pkg) {
            if (Prefs.blockRedirect(this) && !isExcluded(pkg) &&
                Rules.isAdLanding(cls) && now - s.start <= REDIRECT_WINDOW_MS
            ) {
                backFromAd(pkg, "落地页 $cls") { currentClass == cls }
            }
            return
        }

        // 情况 B：刚从桌面点开的应用，几秒内被带去了另一个应用（浏览器、应用商店、淘宝……）。
        // lastLauncherAt <= s.start 表示这期间没回过桌面，说明不是用户自己切换的。
        if (s != null && s.fromLauncher && lastLauncherAt <= s.start &&
            now - s.start <= REDIRECT_WINDOW_MS &&
            Prefs.blockRedirect(this) && !isExcluded(s.pkg) && !isExcluded(pkg) &&
            isRedirectTarget(pkg)
        ) {
            backFromAd(s.pkg, "跳转到 $pkg") { currentPkg == pkg }
            return // 保持原会话不变
        }

        // 情况 C：新的应用切入前台，开启新会话，并开始找“跳过”
        session = Session(pkg, now, fromLauncher = prev != null && prev in homes)
        main.removeCallbacks(poll)
        main.post(poll)
    }

    // ------------------------------------------------------------------ 开屏“跳过”

    private val poll = object : Runnable {
        override fun run() {
            val s = session ?: return
            if (SystemClock.elapsedRealtime() - s.start > SPLASH_WATCH_MS) return
            try {
                scanForSkip(s, throttle = false)
            } catch (e: Throwable) {
                Log.w(TAG, "poll failed", e)
            }
            main.postDelayed(this, POLL_MS)
        }
    }

    private fun scanForSkip(s: Session, throttle: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - s.start > SPLASH_WATCH_MS || now < s.skipBlockedUntil) return
        if (!Prefs.skipSplash(this) || isExcluded(s.pkg)) return
        if (throttle && now - lastScanAt < MIN_SCAN_GAP_MS) return
        lastScanAt = now

        val root = rootInActiveWindow ?: return
        try {
            if (root.packageName?.toString() != s.pkg) return
            val b = Rect()
            root.getBoundsInScreen(b)
            val dim = maxOf(b.width(), b.height()).takeIf { it > 0 }
                ?: resources.displayMetrics.heightPixels
            val hit = findSkip(root, dim) ?: return
            s.skipBlockedUntil = now + SKIP_COOLDOWN_MS
            clickNode(hit.node) { ok ->
                if (ok) {
                    StatsStore.record(this, s.pkg, StatsStore.TYPE_SPLASH, hit.why)
                    Log.i(TAG, "splash skipped: ${s.pkg} ${hit.why}")
                } else {
                    s.skipBlockedUntil = 0L // 没点成功，允许下一轮重试
                }
                safeRecycle(hit.node)
            }
        } finally {
            safeRecycle(root)
        }
    }

    /** 深度优先找第一个“跳过”节点。命中的节点不回收，由调用方用完后回收。 */
    private fun findSkip(root: AccessibilityNodeInfo, maxDim: Int): Hit? {
        var visited = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int): Hit? {
            if (++visited > MAX_NODES || depth > MAX_DEPTH) return null
            if (n.isVisibleToUser) {
                val why = Rules.matchSkip(n, maxDim)
                if (why != null) return Hit(n, why)
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                val hit = walk(c, depth + 1)
                if (hit == null) {
                    safeRecycle(c)
                } else {
                    if (hit.node !== c) safeRecycle(c)
                    return hit
                }
            }
            return null
        }
        return walk(root, 0)
    }

    private fun clickNode(node: AccessibilityNodeInfo, done: (Boolean) -> Unit) {
        // 1) 自己或最近的可点击祖先，直接触发点击
        var t: AccessibilityNodeInfo? = node
        var up = 0
        while (t != null && up <= 4) {
            if (t.isClickable && t.isEnabled && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                done(true)
                return
            }
            t = t.parent
            up++
        }
        // 2) 没有可点击的控件（按钮靠 onTouch 实现的广告 SDK 很常见）：在中心位置模拟一次手指点击
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) {
            done(false)
            return
        }
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) = done(true)
                override fun onCancelled(gestureDescription: GestureDescription?) = done(false)
            },
            null
        )
        if (!accepted) done(false)
    }

    // ------------------------------------------------------------------ 误触跳转：自动返回

    private fun backFromAd(srcPkg: String, detail: String, stillThere: () -> Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRedirectAt < REDIRECT_COOLDOWN_MS) return
        lastRedirectAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        StatsStore.record(this, srcPkg, StatsStore.TYPE_REDIRECT, detail)
        Log.i(TAG, "redirect blocked: $srcPkg $detail")
        retryBack(1, stillThere)
    }

    /** 有些页面第一次返回会被拦截（比如弹“确定离开吗”），最多再按两次，且只有还停在广告页时才按。 */
    private fun retryBack(attempt: Int, stillThere: () -> Boolean) {
        if (attempt > MAX_BACK_RETRY) return
        main.postDelayed({
            try {
                if (instance === this && stillThere()) {
                    lastRedirectAt = SystemClock.elapsedRealtime()
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    retryBack(attempt + 1, stillThere)
                }
            } catch (e: Throwable) {
                Log.w(TAG, "retry back failed", e)
            }
        }, 900L)
    }

    // ------------------------------------------------------------------ 环境信息

    private fun isExcluded(pkg: String) = pkg in Prefs.excluded(this)

    private fun isRedirectTarget(pkg: String): Boolean =
        pkg in Rules.JUMP_TARGETS || userAppCache.getOrPut(pkg) { isUserApp(pkg) }

    private fun isUserApp(pkg: String): Boolean = try {
        val f = packageManager.getApplicationInfo(pkg, 0).flags
        (f and ApplicationInfo.FLAG_SYSTEM) == 0 ||
            (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
    } catch (e: PackageManager.NameNotFoundException) {
        false // 看不到的包（系统组件等）一律不当作跳转目标
    }

    @Suppress("DEPRECATION")
    private fun refreshEnv() {
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homes = packageManager.queryIntentActivities(home, 0)
                .map { it.activityInfo.packageName }
                .toSet()
        } catch (e: Throwable) {
            Log.w(TAG, "query launchers failed", e)
        }
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imes = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Throwable) {
            Log.w(TAG, "query IMEs failed", e)
        }
        userAppCache.clear()
        envAt = SystemClock.elapsedRealtime()
    }

    @Suppress("DEPRECATION")
    private fun safeRecycle(n: AccessibilityNodeInfo?) {
        try {
            n?.recycle() // Android 13+ 已是空操作；旧版本回收到对象池
        } catch (e: Throwable) {
            // 已被回收过，忽略
        }
    }
}
