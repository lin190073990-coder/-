package com.qingping.adblock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 开机 / 覆盖安装后自检。
 * 已启用的无障碍服务由系统在开机解锁后自动拉起，这里不需要“启动”什么，
 * 只负责一件事：发现服务被关了，就自愈（有 ADB 授权时）或发通知提醒。
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON" -> Guard.ensureAlive(context, notify = true)
        }
    }
}
