package com.qingping.adblock

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import java.util.concurrent.Executors

data class AppStat(val pkg: String, val splash: Int, val redirect: Int, val lastTs: Long) {
    val total: Int get() = splash + redirect
}

data class EventRow(val type: Int, val ts: Long, val detail: String)

/**
 * 统计存储：每次“跳过 / 返回”写一行事件，按应用、按时间范围聚合查询。
 * 所有读写都在同一个后台线程里串行执行，回调回到主线程。
 */
object StatsStore {
    const val TYPE_SPLASH = 0    // 自动点了“跳过”
    const val TYPE_REDIRECT = 1  // 广告跳转后自动返回

    private const val KEEP_DAYS = 400L

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var helper: Helper? = null

    private class Helper(ctx: Context) : SQLiteOpenHelper(ctx, "qingping.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE events(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "pkg TEXT NOT NULL, type INTEGER NOT NULL, " +
                    "ts INTEGER NOT NULL, detail TEXT)"
            )
            db.execSQL("CREATE INDEX idx_events_ts ON events(ts)")
            db.execSQL("CREATE INDEX idx_events_pkg ON events(pkg, ts)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    private fun db(ctx: Context): SQLiteDatabase {
        val h = helper ?: synchronized(this) {
            helper ?: Helper(ctx.applicationContext).also { helper = it }
        }
        return h.writableDatabase
    }

    fun record(ctx: Context, pkg: String, type: Int, detail: String) {
        val app = ctx.applicationContext
        io.execute {
            try {
                val cv = ContentValues().apply {
                    put("pkg", pkg)
                    put("type", type)
                    put("ts", System.currentTimeMillis())
                    put("detail", detail.take(200))
                }
                db(app).insert("events", null, cv)
            } catch (e: Throwable) {
            }
        }
    }

    fun loadStats(ctx: Context, sinceTs: Long, cb: (List<AppStat>) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            val out = ArrayList<AppStat>()
            try {
                db(app).rawQuery(
                    "SELECT pkg, " +
                        "SUM(CASE WHEN type=0 THEN 1 ELSE 0 END), " +
                        "SUM(CASE WHEN type=1 THEN 1 ELSE 0 END), " +
                        "MAX(ts) FROM events WHERE ts>=? " +
                        "GROUP BY pkg ORDER BY COUNT(*) DESC, MAX(ts) DESC",
                    arrayOf(sinceTs.toString())
                ).use { c ->
                    while (c.moveToNext()) {
                        out.add(AppStat(c.getString(0), c.getInt(1), c.getInt(2), c.getLong(3)))
                    }
                }
            } catch (e: Throwable) {
            }
            main.post { cb(out) }
        }
    }

    fun loadRecent(ctx: Context, pkg: String, limit: Int, cb: (List<EventRow>) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            val out = ArrayList<EventRow>()
            try {
                db(app).rawQuery(
                    "SELECT type, ts, COALESCE(detail,'') FROM events " +
                        "WHERE pkg=? ORDER BY ts DESC LIMIT $limit",
                    arrayOf(pkg)
                ).use { c ->
                    while (c.moveToNext()) {
                        out.add(EventRow(c.getInt(0), c.getLong(1), c.getString(2)))
                    }
                }
            } catch (e: Throwable) {
            }
            main.post { cb(out) }
        }
    }

    fun prune(ctx: Context) {
        val app = ctx.applicationContext
        io.execute {
            try {
                val cutoff = System.currentTimeMillis() - KEEP_DAYS * 86_400_000L
                db(app).delete("events", "ts<?", arrayOf(cutoff.toString()))
            } catch (e: Throwable) {
            }
        }
    }

    fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
