# 清屏（QingPing）

自动跳过其他应用的开屏广告，在广告误触跳转到别处时自动返回，并按应用统计次数。
Kotlin，无第三方依赖（只用 AppCompat 和 Material），minSdk 26，targetSdk 35。**没有 INTERNET 权限，数据只存在本机。**

## 它是怎么工作的

清屏靠“无障碍服务”读取前台界面，再替你点按钮。这是不 root 时普通应用能做到的上限：
**它不会在广告加载前拦截，而是在广告出现后立刻识别、立刻跳过**，所以广告可能闪现不到一秒。

| 功能 | 做法 | 代码位置 |
| --- | --- | --- |
| 开屏跳过 | 应用切入前台后的 7 秒内，每 250 ms 扫描一次控件树，找到“跳过 / Skip / 3s 跳过”等文字、描述或控件 ID，先 `ACTION_CLICK`，不行就在中心位置模拟手指点击 | `AdSkipService.scanForSkip` |
| 误触跳转 | 从桌面点开应用后的 6 秒内：跳到浏览器、应用商店或其他已安装应用，或出现广告落地页 Activity，就自动按“返回”（最多补按两次） | `AdSkipService.onWindowChanged` |
| 统计 | 每次动作写入 SQLite；界面按“今日 / 近 7 天 / 累计”聚合，点应用可看最近记录 | `StatsStore`、`MainActivity` |
| 开机自检 | 已启用的无障碍服务由系统在开机解锁后拉起；`BootReceiver` 只负责发现服务被关，然后自愈或发通知 | `BootReceiver`、`Guard` |
| 识别规则 | 文字、控件 ID、落地页类名、跳转目标都集中在一个文件里 | `Rules.kt` |

## 构建与运行

1. 用 Android Studio（近两年的版本即可）打开本文件夹，等待 Gradle 同步。需要 JDK 17 以上，Android Studio 自带。
2. SDK 里装好 Android 15（API 35）。手机或模拟器需要 Android 8.0（API 26）以上。
3. 点 Run 安装。没有附带 `gradlew`；命令行构建请先执行 `gradle wrapper --gradle-version 8.9`。
4. 同步时如果 Android Studio 提示升级 AGP 或 Kotlin，按提示升级即可。

## 获取 APK

这份是源码工程，需要编译一次才有 APK。三种办法：

1. **电脑加 Android Studio（最省事）**：打开本文件夹，菜单 Build → Build Bundle(s) / APK(s) → Build APK(s)，完成后点提示里的 locate。文件在 `app/build/outputs/apk/debug/app-debug.apk`。命令行的话，先 `gradle wrapper --gradle-version 8.9`，再 `./gradlew assembleDebug`。
2. **不装任何东西，用 GitHub 在线构建**（手机网页也能操作）：
   1. 新建一个 GitHub 仓库。
   2. 把 `QingPing-Android.zip` 上传到仓库根目录（不用解压）。
   3. 在仓库里新建文件，文件名填 `.github/workflows/build-apk.yml`（带斜杠会自动建文件夹），内容粘贴本工程 `.github/workflows/build-apk.yml` 的全部文字，提交。
   4. 打开仓库的 Actions 页面，等 “Build APK” 跑完（几分钟），在运行结果底部的 Artifacts 里下载 `QingPing-debug-apk`，解压得到 `app-debug.apk`。
   如果你把整个工程文件夹的内容直接放在仓库根目录，也可以，工作流会自动识别。
3. 已经有安卓开发环境的朋友帮你编译。

安装：把 APK 传到手机，按提示允许“安装未知应用”。Play Protect 提示“未经验证的应用”时选“仍然安装”。这是调试签名的版本，只适合自用；以后换了签名，要先卸载旧版再装。

## 首次使用

1. 打开清屏，点“开启服务”，在系统的无障碍设置里找到“清屏”并开启。
2. Android 13 及以上，如果开关是灰色的：设置 → 应用 → 清屏 → 右上角菜单 → 允许受限制的设置，然后回去开启。
3. （可选，推荐）授权自愈。手机开启 USB 调试，电脑执行一次：
   `adb shell pm grant com.qingping.adblock android.permission.WRITE_SECURE_SETTINGS`
   部分厂商还需要在开发者选项里开启“USB 调试（安全设置）”。授权后，开机或被系统关闭无障碍时，清屏会自己重新开启。
4. 点“保活设置”：忽略电池优化、打开自启动、在最近任务里锁定清屏。
5. 打开一个有开屏广告的应用试试，回到清屏看统计。

## 保活：能做到什么，做不到什么

- 能做到：开机后无障碍服务由系统自动拉起；划掉最近任务在原生系统上不影响服务；有 ADB 授权时，服务被关后打开应用或开机会自动重新开启。
- 做不到：“强行停止”（部分国产 ROM 的一键清理、划掉任务等同于它）会让系统直接把无障碍服务从已开启列表里移除，应用自己拦不住。被强行停止的应用也收不到开机广播，所以要等你再打开一次清屏。
- 自愈会重新开启服务，哪怕你是在系统设置里手动关掉的。想暂停清屏，请关闭应用内的两个开关。

## 调试与调规则

- 抓日志：`adb logcat -s Qingping:D`。每次切换窗口都会打印“应用包名 / Activity 类名”，命中跳过或返回时会打印原因。
- 找广告落地页类名：触发一次广告跳转后执行
  `adb shell dumpsys activity activities | grep -i resumed`
- 某个应用的“跳过”识别不到：用 Android Studio 的 Layout Inspector 或 `uiautomator dump` 看那个按钮的 text、content-desc、resource-id，把规律加进 `Rules.kt`。
- 某个应用被误点：在统计列表里点它，选“暂停对此应用的拦截”。

## 已知限制

- 只能处理“有控件节点”的界面。游戏引擎、H5 页面、自绘视频开屏、没有文字也没有 ID 的按钮识别不到。要覆盖它们，需要截图加 OCR（`AccessibilityService.takeScreenshot`，Android 11+），本工程没有包含。
- 摇一摇、滑动触发的跳转无法禁用，只能跳转后返回。
- 规则里的类名和控件 ID 会随广告 SDK 改版失效，需要持续维护。
- 不是无障碍辅助工具，所以刻意没有设置 `isAccessibilityTool`，也不要设置。较新的 Android（据测试版报道，17 起）在用户开启“高级保护”后，会撤销非无障碍工具应用的无障碍权限，这是系统限制，需要关闭该模式。
- 这类自动点击应用很难通过 Google Play 和主流应用商店审核，适合自用侧载。
- 本工程没有在真机上跑过，首次运行请先在自己常用的几个应用上试一遍。

## 可以继续做的方向

- DNS / VPN 过滤（`VpnService`）：真正在加载前挡住一部分广告请求，但会占用系统唯一的 VPN 槽位，也挡不住写死 IP 或 DoH 的 SDK。
- 规则云更新：把 `Rules.kt` 里的列表改成可下载的 JSON（需要加 INTERNET 权限，会改变“完全离线”的承诺）。
- 截图 + OCR 兜底，覆盖没有控件节点的开屏。
